let gameState = "menu";
let player;
let obstacles = [];
let obstacleSpeed = 4;
let backgroundColor;
let playerEmoji = "🚗";
let obstacleEmoji = "🚧";

function setup() {
  createCanvas(600, 400);
  textAlign(CENTER, CENTER);
  textSize(32);
  player = new Player();
}

function draw() {
  if (gameState === "menu") {
    showMenu();
  } else if (gameState === "campo" || gameState === "cidade") {
    runGame();
  }
}

function showMenu() {
  background(200);
  textAlign(CENTER, CENTER);
  textSize(24);
  fill(0);
  text("Escolha o circuito:", width / 2, height / 2 - 40);
  text("Pressione C para Campo 🌳", width / 2, height / 2);
  text("Pressione D para Cidade 🚧", width / 2, height / 2 + 40);
}

function keyPressed() {
  if (gameState === "menu") {
    if (key === "c" || key === "C") {
      gameState = "campo";
      backgroundColor = color(100, 200, 100);
      playerEmoji = "🚜";
      obstacleEmoji = "🌳";
      resetGame();
    } else if (key === "d" || key === "D") {
      gameState = "cidade";
      backgroundColor = color(180);
      playerEmoji = "🚗";
      obstacleEmoji = "🚧";
      resetGame();
    }
  }
}

function runGame() {
  background(backgroundColor);
  player.update();
  player.show();

  if (frameCount % 60 === 0) {
    obstacles.push(new Obstacle());
  }

  for (let i = obstacles.length - 1; i >= 0; i--) {
    obstacles[i].update();
    obstacles[i].show();

    if (obstacles[i].hits(player)) {
      gameState = "menu"; // volta pro menu ao colidir
      break;
    }

    if (obstacles[i].offscreen()) {
      obstacles.splice(i, 1);
    }
  }
}

function resetGame() {
  obstacles = [];
  player = new Player();
}

// Classe do jogador com emoji
class Player {
  constructor() {
    this.x = 50;
    this.y = height / 2;
    this.size = 32;
  }

  update() {
    if (keyIsDown(UP_ARROW)) this.y -= 5;
    if (keyIsDown(DOWN_ARROW)) this.y += 5;
    this.y = constrain(this.y, 0, height - this.size);
  }

  show() {
    textSize(this.size);
    text(playerEmoji, this.x, this.y);
  }

  getBounds() {
    return { x: this.x - 16, y: this.y - 16, w: 32, h: 32 };
  }
}

// Obstáculo com emoji
class Obstacle {
  constructor() {
    this.x = width;
    this.y = random(height - 32);
    this.size = 32;
  }

  update() {
    this.x -= obstacleSpeed;
  }

  show() {
    textSize(this.size);
    text(obstacleEmoji, this.x, this.y);
  }

  hits(player) {
    let p = player.getBounds();
    let o = { x: this.x - 16, y: this.y - 16, w: 32, h: 32 };
    return collideRectRect(p.x, p.y, p.w, p.h, o.x, o.y, o.w, o.h);
  }

  offscreen() {
    return this.x + this.size < 0;
  }
}